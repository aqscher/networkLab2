Run command on unix
    client:
        -> python3 client.py <ipaddr> <portnum>
    server:
        -> ./server <portnum>